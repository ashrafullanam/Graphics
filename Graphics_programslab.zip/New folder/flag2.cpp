#include<iostream>
#include<graphics.h>
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>

using namespace std;

int main()
{
    int gdriver = DETECT, gmode;
    initgraph(&gdriver, &gmode, "..\\bgi");
    setcolor(3);
    rectangle(92,100,100,400);
    setfillstyle(2,3);
    floodfill(99,200,3);
    setcolor(2);
    rectangle(100,100,400,250);
    setfillstyle(1,2);
    floodfill(150,200,2);
    setcolor(4);
    circle(250,180,50);
    setfillstyle(1,4);
    floodfill(255,180,4);
    getch();
    return 0;
}
