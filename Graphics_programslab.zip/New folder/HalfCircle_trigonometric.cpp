#include<graphics.h>
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<math.h>

int main()
{
    int gdriver = DETECT, gmode;
    initgraph(&gdriver,&gmode,"..\\bgi");

    float x,y,r,h,k,theta;
    printf("Enter Radius of Circle:");
    scanf("%f",&r);
    printf("Enter Circle Center:");
    scanf("%f %f",&h,&k);
    for(theta=3.1416+3.1416/2;theta<=2*3.1416+3.1416/2;theta=theta+.01)
    {
        x=r*cos(theta);
        y=r*sin(theta);
        putpixel(x+h,y+k,4);

        delay(1);
    }

    getchar();
    return 0;
}
