#include<graphics.h>
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<math.h>
int main()
{
    int gdriver = DETECT, gmode;
    initgraph(&gdriver,&gmode,"..\\bgi");

    float x,y,r,h,k;
    printf("Enter Radius of Circle:");
    scanf("%f",&r);
    printf("Enter Circle Center:");
    scanf("%f %f",&h,&k);
    for(x=0;x<=r/sqrt(2);x++)
    {
        y=sqrt(r*r-x*x);
        putpixel(x+h,y+k,4);
        putpixel(-x+h,y+k,14);
        putpixel(x+h,-y+k,2);
        putpixel(-x+h,-y+k,5);
        putpixel(y+h,x+k,10);
        putpixel(-y+h,x+k,3);
        putpixel(y+h,-x+k,13);
        putpixel(-y+h,-x+h,15);
        delay(100);
    }

    getchar();
    return 0;
}
