#include<graphics.h>
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<math.h>
#define PIE 3.1416
int main()
{
    int gdriver = DETECT, gmode;
    initgraph(&gdriver,&gmode,"..\\bgi");

    float x,y,r,h,k,t;
    printf("Enter Radius of Circle:");
    scanf("%f",&r);
    printf("Enter Circle Center:");
    scanf("%f %f",&h,&k);
    for(t=0;t<=PIE/4;t=t+.01)
    {
        x=r*cos(t);
        y=r*sin(t);
        putpixel(x+h,y+k,4);
        putpixel(-x+h,y+k,14);
        putpixel(x+h,-y+k,2);
        putpixel(-x+h,-y+k,5);
        putpixel(y+h,x+k,10);
        putpixel(-y+h,x+k,3);
        putpixel(y+h,-x+k,13);
        putpixel(-y+h,-x+k,15);
        delay(300);
    }

    getchar();
    return 0;
}
