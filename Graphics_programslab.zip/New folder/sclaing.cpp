#include<graphics.h>
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>
int main()
{
int gdriver = DETECT, gmode;
initgraph (&gdriver, &gmode, "..\\bgi");
float x,y,x3,y3,x1,y1,x2,y2,sx,sy;

sx=.5;
sy=1;
printf("Enter start point of a line:  ");
scanf("%f%f",&x1,&y1);

printf("Enter end point of a line:  ");
scanf("%f%f",&x2,&y2);

setcolor(4);
rectangle(x1,y1,x2,y2);
//setfillstyle(1,2);
//floodfill(101,101,4);

x=x1*sx;
y=y1*sy;

x3=x2*sx;
y3=y2*sy;
//getch();
//cleardevice();
setcolor(11);
rectangle(x,y,x3,y3);
//setfillstyle(1,3);
//floodfill(x+1,y+1,11);

getch();
return 0;
}

