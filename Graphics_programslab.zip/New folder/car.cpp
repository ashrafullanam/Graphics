#include<graphics.h>
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>

int main()
{
    int gdriver = DETECT, gmode;
    initgraph(&gdriver, &gmode, "..\\bgi");
    setcolor(3);
    for(int i=0; i<=100; i=i+5)
    {
        circle(300+i,200,50);
        circle(500+i,200,50);
        line(200+i,150,600+i,150);
        line(250+i,150,250+i,120);
        line(550+i,150,550+i,120);
        line(250+i,120,270+i,120);
        line(550+i,120,530+i,120);
        line(270+i,120,275+i,100);
        line(530+i,120,525+i,100);
        line(275+i,100,525+i,100);
        delay(500);
        cleardevice();
    }
    getch();
    return 0;
}
