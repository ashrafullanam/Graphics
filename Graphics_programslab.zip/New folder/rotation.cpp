#include<graphics.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<math.h>
int main()
{
    int gdriver = DETECT, gmode;
    initgraph(&gdriver,&gmode,"..\\bgi");

    float r=50,h=500,k=300,theta,x,y;
    circle(300,300,100);

    for(theta=0;theta<=2*3.1416;theta=theta+.1)
    {
       setcolor(14);
       x=200*cos(theta);
       y=200*sin(theta);

       putpixel(x+300,y+300,15);
       circle(x+300,y+300,r);
       setfillstyle(0,14);
       floodfill(x+300,y+300,4);
       line(300,300,x+300,y+300);
       delay(30);
       cleardevice();
    }
    getchar();
    return 0;
}
